public class Habits {

    private boolean Smoking;
    private boolean Alcohol;
    private boolean DailyExcercise;
    private boolean Drugs;

    public Habits(boolean smoking, boolean alcohol, boolean dailyExcercise, boolean drugs) {
        Smoking = smoking;
        Alcohol = alcohol;
        DailyExcercise = dailyExcercise;
        Drugs = drugs;
    }

    public boolean isSmoking() {
        return Smoking;
    }

    public void setSmoking(boolean smoking) {
        Smoking = smoking;
    }

    public boolean isAlcohol() {
        return Alcohol;
    }

    public void setAlcohol(boolean alcohol) {
        Alcohol = alcohol;
    }

    public boolean isDailyExcercise() {
        return DailyExcercise;
    }

    public void setDailyExcercise(boolean dailyExcercise) {
        DailyExcercise = dailyExcercise;
    }

    public boolean isDrugs() {
        return Drugs;
    }

    public void setDrugs(boolean drugs) {
        Drugs = drugs;
    }
}
