public class CustomerDetails {

    private String name;
    private Gender  gender ;
    private int age;
    private CurHealth curHealth;
    private Habits habits;

    public CustomerDetails(String name, Gender gender, int age, CurHealth curHealth, Habits habits) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.curHealth = curHealth;
        this.habits = habits;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public CustomerDetails() {
        this.name = name;
        this.age = age;
        this.curHealth = curHealth;
        this.habits = habits;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public CurHealth getCurHealth() {
        return curHealth;
    }

    public void setCurHealth(CurHealth curHealth) {
        this.curHealth = curHealth;
    }

    public Habits getHabits() {
        return habits;
    }

    public void setHabits(Habits habits) {
        this.habits = habits;
    }
}
