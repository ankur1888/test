import java.util.ArrayList;
import java.util.HashMap;

public class MainPremiumCalculation {

    public static void main(String[] args) {

        // Create the input
        CurHealth curHealth = new CurHealth(false, false, false, true);
        Habits habits = new Habits(false, true, true, false);
        CustomerDetails customerDetails = new CustomerDetails("Norman Gomes", Gender.MALE, 34,curHealth, habits );

        //Create LastName
        String[] name = customerDetails.getName().split(" ");
        String lastName = name[1];

        //Create Salutation
        String salutation;
        if(customerDetails.getGender().equals(Gender.MALE)){
            salutation = "Mr.";
        }
        else if (customerDetails.getGender().equals(Gender.FEMALE)){
            salutation = "Mrs.";
        }
        else{
            salutation = "";
        }

        //Create Object Reference of PremiumCalculate Class
        PremiumCalculate premiumCalculate = new PremiumCalculate();

        //Call Calculate Premium method of PremiumCalculate Class
        int premium = (int)premiumCalculate.calculatePremium(customerDetails);

        //Final Output Display
        System.out.println("Health Insurance Premium for " + salutation + lastName + ": Rs." + premium);

    }
}
