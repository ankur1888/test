import java.util.ArrayList;

public class PremiumCalculate {

    double basePremium = 5000;

    public double calculateBasePremium(int age) {

        if (age < 18) {
            return basePremium;
        }
        else if (age >= 18 && age < 25) {
            basePremium= 1.10 * basePremium;
        }
        else if (age >= 25 && age < 40) {
            int quotient = age / 5;
            basePremium= Math.round((Math.pow(1.10, (quotient - 3)) * basePremium));
        }
        else if (age >= 40 && age < 45) {
            int quotient = age / 5;
            double base = Math.pow(1.10, 5)* basePremium;
            basePremium= Math.round(( Math.pow(1.20, (quotient - 7))* base));
        }
        return basePremium;
    }

    public int countHealth(CurHealth curHealth){

            ArrayList<Boolean> healthList = new ArrayList<>();
            healthList.add(curHealth.isBloodPressure());
            healthList.add(curHealth.isBloodSugar());
            healthList.add(curHealth.isHypertension());
            healthList.add(curHealth.isOverWeight());

            int healthCount = 0;
            for (int i=0; i<healthList.size(); i++){
                if(healthList.get(i) == true){
                    healthCount = healthCount + 1;
                    //System.out.println(healthCount);
                }
            }
            return healthCount;
        }
    public int countGoodHabits(Habits habits){

        ArrayList<Boolean> goodHabitsList = new ArrayList<>();
        goodHabitsList.add((habits.isDailyExcercise()));

        int goodHabitsCount = 0;
        for (int i=0; i<goodHabitsList.size(); i++){
            if(goodHabitsList.get(i) == true){
                goodHabitsCount = goodHabitsCount + 1;
            }
        }
        //System.out.println("GOOD HABITS COUNT:" + goodHabitsCount);

        return goodHabitsCount;
    }

    public int countBadHabits(Habits habits){

        ArrayList<Boolean> badHabitsList = new ArrayList<>();
        badHabitsList.add(habits.isAlcohol());
        badHabitsList.add(habits.isDrugs());
        badHabitsList.add(habits.isSmoking());

        int badHabitsCount = 0;
        for (int i=0; i<badHabitsList.size(); i++){
            if(badHabitsList.get(i) == true){
                badHabitsCount = badHabitsCount + 1;
            }
        }
        //System.out.println("BAD HABITS COUNT:" + badHabitsCount);

        return badHabitsCount;
    }


    public double calculatePremium(CustomerDetails customerDetails) {

        //1. Calculate Base Premium on the basis of Age
            basePremium = calculateBasePremium(customerDetails.getAge());
            //System.out.println("After Age:" + basePremium);

        //2. Calculate Premium on the basis of Gender
        if (customerDetails.getGender().equals(Gender.MALE)) {
            basePremium = Math.round(1.02 * basePremium);
            //System.out.println("After Gender:" + basePremium);
        }
        else{
            //System.out.println("After Gender:" + basePremium);
        }

        //3.Calculate Premium on the basis of Health
        int healthCount = countHealth(customerDetails.getCurHealth());
            basePremium = Math.round((1+(0.01 * healthCount)) * basePremium);
            //System.out.println("After Health:" + basePremium);

        //4.Calculate total number of Good Habits Count
        int goodHabitsCount = countGoodHabits(customerDetails.getHabits());

        //5.Calculate total number of Bad Habits Count
        int badHabitsCount = countBadHabits(customerDetails.getHabits());

        //6. Calculate Total premium
            basePremium = Math.round((1+(0.03 * (badHabitsCount-goodHabitsCount))) * basePremium);
            //System.out.println("Total Premium:" + basePremium);

            return basePremium;
    }

    }



